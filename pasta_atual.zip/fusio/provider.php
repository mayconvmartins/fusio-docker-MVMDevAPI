<?php

return [
    \Fusio\Adapter\Amqp\Adapter::class,
    \Fusio\Adapter\Beanstalk\Adapter::class,
    \Fusio\Adapter\Cli\Adapter::class,
    \Fusio\Adapter\Elasticsearch\Adapter::class,
    \Fusio\Adapter\Fcgi\Adapter::class,
    \Fusio\Adapter\File\Adapter::class,
    \Fusio\Adapter\GraphQL\Adapter::class,
    \Fusio\Adapter\Http\Adapter::class,
    \Fusio\Adapter\Memcache\Adapter::class,
    \Fusio\Adapter\Mongodb\Adapter::class,
    \Fusio\Adapter\Php\Adapter::class,
    \Fusio\Adapter\Redis\Adapter::class,
    \Fusio\Adapter\SdkFabric\Adapter::class,
    \Fusio\Adapter\Smtp\Adapter::class,
    \Fusio\Adapter\Soap\Adapter::class,
    \Fusio\Adapter\Sql\Adapter::class,
    \Fusio\Adapter\Stripe\Adapter::class,
    \Fusio\Adapter\Util\Adapter::class,
    \Fusio\Adapter\Worker\Adapter::class,
];