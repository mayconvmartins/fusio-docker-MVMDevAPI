#!/bin/bash

# Define o diretório base
BASE_DIR="/mvm/fusio-docker-MVMDevAPI"

# Ajusta o proprietário e as permissões das pastas e arquivos, exceto a pasta db
find "$BASE_DIR" -path "$BASE_DIR/db" -prune -o -exec chown www-data:www-data {} \;
find "$BASE_DIR" -path "$BASE_DIR/db" -prune -o -exec chmod 755 {} \;

# Ajusta permissões específicas para arquivos
find "$BASE_DIR" -type f -exec chmod 644 {} \;
find "$BASE_DIR" -type d -exec chmod 755 {} \;

# Ajusta permissões de execução para scripts específicos
chmod +x "$BASE_DIR/docker-entrypoint.sh"
chmod +x "$BASE_DIR/bin/fusio"

# Reinicia os contêineres para aplicar as mudanças
docker-compose down
docker-compose up -d

echo "Permissões ajustadas e contêineres reiniciados com sucesso."
